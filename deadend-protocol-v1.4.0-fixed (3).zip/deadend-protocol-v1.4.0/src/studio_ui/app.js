/* DeadEnd Studio -- front-end. Vanilla JS, no dependencies, fully offline. */
"use strict";

/* ------------------------------------------------------------- helpers -- */
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;")
  .replace(/>/g, "&gt;").replace(/"/g, "&quot;");

async function post(url, obj) {
  const r = await fetch(url, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(obj || {}),
  });
  return r.json();
}
async function get(url) { const r = await fetch(url); return r.json(); }

function fmtSize(n) {
  if (n > 1048576) return (n / 1048576).toFixed(1) + " MB";
  if (n > 1024) return Math.round(n / 1024) + " KB";
  return n + " B";
}
function fmtWhen(t) {
  const d = new Date(t * 1000), now = new Date();
  if (d.toDateString() === now.toDateString())
    return d.toTimeString().slice(0, 5);
  return d.toISOString().slice(0, 10);
}
function toast(msg, kind) {
  const t = document.createElement("div");
  t.className = "toast " + (kind || "");
  t.textContent = msg;
  $("toasts").appendChild(t);
  setTimeout(() => t.remove(), 2800);
}

/* --------------------------------------------------------- highlighting -- */
const KW = new Set(("set to print if then else end repeat times forever with from by " +
  "while function return break continue for each in and or not is more than greater " +
  "less fewer bigger smaller of at least most has yes no nothing true false use game " +
  "app kit make window when starts every frame run change exit button clicked add " +
  "remove item").split(" "));
const BI = new Set(("ask random number text count first last upper lower trim split " +
  "join find replace abs floor ceiling round sqrt sin cos tan atan power min max clock " +
  "distance keys exists save load sound music silence clear pixel line box circle ring " +
  "write image title sort reverse shuffle holding pressed hits mouse time delta " +
  "fullscreen").split(" "));

function hlLine(line) {
  let out = "", i = 0;
  const n = line.length;
  const sp = (cls, txt) => '<span class="tk-' + cls + '">' + esc(txt) + "</span>";
  while (i < n) {
    const c = line[i];
    if (c === "#") { out += sp("cm", line.slice(i)); break; }
    if (c === '"') {
      let j = i + 1;
      while (j < n && line[j] !== '"') j++;
      out += sp("str", line.slice(i, Math.min(j + 1, n)));
      i = j + 1; continue;
    }
    if (/[0-9]/.test(c) && !/[A-Za-z0-9_]/.test(line[i - 1] || "")) {
      let j = i;
      while (j < n && /[0-9._]/.test(line[j])) j++;
      if (line[j] === "e" || line[j] === "E") { j++; if ("+-".includes(line[j])) j++; while (j < n && /[0-9]/.test(line[j])) j++; }
      out += sp("num", line.slice(i, j)); i = j; continue;
    }
    if (/[A-Za-z_]/.test(c)) {
      let j = i;
      while (j < n && /[A-Za-z0-9_]/.test(line[j])) j++;
      const w = line.slice(i, j);
      let k = j; while (k < n && line[k] === " ") k++;
      const cls = KW.has(w) ? "kw" : BI.has(w) ? "bi"
        : (line[k] === "(" && !KW.has(w)) ? "fn" : null;
      out += cls ? sp(cls, w) : esc(w);
      i = j; continue;
    }
    out += esc(c); i++;
  }
  return out;
}

/* ------------------------------------------------------------- state ----- */
let info = { files: [], examples: [], docs: [], preview: false, can_windows: false,
             native_label: "this PC", version: "", can_tour: false };
let file = null;          // {name, content, origin: 'ws'|'example'|'new'}
let session = null;       // {sid, kind, camera, shots:Set, lastOut, done}
let draftTimer = null;

const ed = $("editor"), hl = $("hl"), hlCode = $("hlCode"),
      gutterInner = $("gutterInner"), gutter = $("gutter");

/* ------------------------------------------------------- editor plumbing */
function highlight() {
  const lines = ed.value.split("\n");
  hlCode.innerHTML = lines.map(hlLine).join("\n") + "\n";
  gutterInner.textContent = lines.map((_, i) => i + 1).join("\n");
}
function syncScroll() {
  hl.scrollTop = ed.scrollTop; hl.scrollLeft = ed.scrollLeft;
  gutter.scrollTop = ed.scrollTop;
}
function insert(t) {
  if (!document.execCommand("insertText", false, t)) {
    ed.setRangeText(t, ed.selectionStart, ed.selectionEnd, "end");
    onEdit();
  }
}
function onEdit() { highlight(); updateDirty(); updateMode(); saveDraft(); }

ed.addEventListener("input", onEdit);
ed.addEventListener("scroll", syncScroll);
ed.addEventListener("click", updateCursor);
ed.addEventListener("keyup", updateCursor);

ed.addEventListener("keydown", (e) => {
  if (e.key === "Tab") { e.preventDefault(); insert("  "); return; }
  if (e.key === "Enter" && !e.shiftKey && !e.ctrlKey && !e.metaKey) {
    e.preventDefault();
    let pos = ed.selectionStart;
    const ls = ed.value.lastIndexOf("\n", pos - 1) + 1;
    let line = ed.value.slice(ls, pos);
    let indent = (line.match(/^[ \t]*/) || [""])[0];
    if (/^\s*(end|else)(\s|$)/.test(line) && indent.length >= 2) {
      const dedented = indent.slice(2) + line.trimStart();
      ed.setSelectionRange(ls, ls + line.length);
      document.execCommand("insertText", false, dedented);
      pos = ls + dedented.length;
    }
    const curLine = ed.value.slice(ed.value.lastIndexOf("\n", pos - 1) + 1, pos);
    const opener = /^(function|if|else|repeat|for|while|when|every)\b/.test(curLine.trim());
    insert("\n" + indent + (opener ? "  " : ""));
  }
});

function updateCursor() {
  const p = ed.selectionStart;
  const before = ed.value.slice(0, p).split("\n");
  $("stPos").textContent = "Ln " + before.length + ", Col " +
    (before[before.length - 1].length + 1);
}
function updateDirty() {
  const dirty = !!file && ed.value !== file.content;
  $("dirtyDot").hidden = !dirty;
}
function updateMode() {
  if (!file) { $("stMode").textContent = "no program"; return; }
  const s = ed.value.toLowerCase();
  const m = s.includes("use game kit") ? "2D game"
    : s.includes("use app kit") ? "windowed app" : "plain program";
  $("stMode").textContent = m + "  ·  " + file.name;
}
function setFile(f) {
  file = f;
  ed.value = f.content;
  file.content = f.content;
  $("welcome").hidden = true;
  $("editorWrap").hidden = false;
  $("fileName").textContent = f.name;
  highlight(); updateDirty(); updateMode();
  ed.focus();
  ed.setSelectionRange(0, 0);       // start at the top, not the end
  ed.scrollTop = 0; ed.scrollLeft = 0;
  syncScroll(); updateCursor();
}
function guardDirty() {
  if (file && ed.value !== file.content)
    return confirm("You have unsaved changes. Throw them away?");
  return true;
}
function gotoLine(n) {
  if (!n || n < 1) return;
  const lines = ed.value.split("\n");
  let pos = 0;
  for (let i = 0; i < n - 1 && i < lines.length; i++) pos += lines[i].length + 1;
  ed.focus();
  ed.setSelectionRange(pos, pos + (lines[n - 1] || "").length);
  const lh = parseFloat(getComputedStyle(ed).lineHeight) || 21;
  ed.scrollTop = Math.max(0, (n - 1) * lh - ed.clientHeight / 2);
  syncScroll(); updateCursor();
  ed.classList.add("flash");
  setTimeout(() => ed.classList.remove("flash"), 700);
}

/* drafts: never lose work */
function saveDraft() {
  if (!file) return;
  clearTimeout(draftTimer);
  draftTimer = setTimeout(() => {
    try { localStorage.setItem("depdraft:" + file.name, ed.value); } catch (e) {}
  }, 700);
}
function checkDraft(name, content) {
  try {
    const d = localStorage.getItem("depdraft:" + name);
    if (d !== null && d !== content && d.trim()) return d;
  } catch (e) {}
  return null;
}
function maybeRestore(name, content) {
  const d = checkDraft(name, content);
  if (d === null) return content;
  return confirm("You have unsaved changes to " + name +
    " from your last session.\nBring them back?") ? d : content;
}

/* ------------------------------------------------------------ console ---- */
function autoscroll() { $("consoleScroll").scrollTop = $("consoleScroll").scrollHeight; }
function clearConsole() {
  $("consoleOut").innerHTML = "";
  $("shotStrip").innerHTML = "";
  $("shotStrip").hidden = true;
}
function consoleNote(text) {
  const d = document.createElement("div");
  d.className = "sys"; d.textContent = text;
  $("consoleOut").appendChild(d); autoscroll();
}
function consoleError(text, line) {
  clearConsole();
  const d = document.createElement("div");
  d.className = "err";
  if (line) d.dataset.line = line;
  d.textContent = text;
  $("consoleOut").appendChild(d); autoscroll();
  if (line) gotoLine(line);
}
function renderOut(text) {
  const box = $("consoleOut");
  box.innerHTML = "";
  const lines = text.split("\n");
  if (lines.length && lines[lines.length - 1] === "") lines.pop();
  const frag = document.createDocumentFragment();
  const start = Math.max(0, lines.length - 2000);
  if (start > 0) {
    const d = document.createElement("div");
    d.className = "sys"; d.textContent = "(older output trimmed)";
    frag.appendChild(d);
  }
  for (let i = start; i < lines.length; i++) {
    const ln = lines[i];
    const d = document.createElement("div");
    if (/deadend error|error:|^dec:/i.test(ln)) {
      d.className = "err";
      const m = ln.match(/line (\d+)/);
      if (m) d.dataset.line = m[1];
    }
    d.textContent = ln || " ";
    frag.appendChild(d);
  }
  box.appendChild(frag); autoscroll();
}
function addShot(url) {
  if (!session || session.shots.has(url)) return;
  session.shots.add(url);
  $("shotStrip").hidden = false;
  const d = document.createElement("div"); d.className = "shot";
  const img = new Image(); img.src = url; img.alt = "game screenshot";
  const cap = document.createElement("span");
  cap.textContent = "live picture " + session.shots.size;
  d.append(img, cap);
  $("shotStrip").appendChild(d); autoscroll();
}
$("consoleOut").addEventListener("click", (e) => {
  const d = e.target.closest("div.err");
  if (d && d.dataset.line) gotoLine(+d.dataset.line);
});
$("consoleClear").onclick = clearConsole;
$("consoleToggle").onclick = () => {
  const p = $("consolePanel");
  p.classList.toggle("collapsed");
  $("consoleToggle").textContent =
    p.classList.contains("collapsed") ? "show" : "hide";
};

/* --------------------------------------------------------------- run ----- */
function setRunBusy(busy, label) {
  $("btnRun").disabled = busy;
  $("runLabel").textContent = busy ? (label || "Working...") : "Run";
}

async function runProgram() {
  if (!file) { toast("Create or open a program first", "err"); return; }
  if (!ed.value.trim()) { toast("Nothing to run -- write some code first", "err"); return; }
  setRunBusy(true, "Compiling");
  clearConsole();
  consoleNote("Compiling your program...");
  try {
    const r = await post("/api/run", { name: file.name, content: ed.value,
                                       asset_base: assetBase() });
    if (!r.ok) {
      consoleError(r.error || "could not run the program", r.line);
      setRunBusy(false);
      return;
    }
    session = { sid: r.sid, kind: r.kind, camera: r.camera,
                shots: new Set(), lastOut: null, done: false };
    if (r.kind === "console") {
      consoleNote("Running. If it asks a question, answer in the box below.");
      $("inputRow").hidden = false;
      setTimeout(() => $("stdinInput").focus(), 200);
    } else if (r.camera) {
      consoleNote("Your game is running in the sandbox -- live pictures appear " +
                  "below as it plays. On your own PC it opens as a real window.");
    } else {
      consoleNote(r.preview
        ? "Game compiled and launched (headless sandbox -- no camera available)."
        : "Game window opened -- switch to it to play. Close it to come back.");
    }
    $("btnStop").hidden = false;
    $("runPill").hidden = false;
    setRunBusy(false);
    pollLoop();
  } catch (e) {
    consoleError("studio hiccup: " + e);
    setRunBusy(false);
  }
}

function pollLoop() {
  if (!session || session.done) return;
  setTimeout(async () => {
    if (!session || session.done) return;
    try {
      const st = await post("/api/poll", { sid: session.sid });
      if (st.error) { finishSession(); return; }
      if (st.out !== session.lastOut) {
        session.lastOut = st.out;
        if (st.out) renderOut(st.out);
      }
      (st.shots || []).forEach(addShot);
      if (!st.alive) { finishSession(st.exit_code); return; }
    } catch (e) { /* transient network blip -- keep polling */ }
    pollLoop();
  }, 380);
}

function finishSession(code) {
  if (!session) return;
  session.done = true;
  session = null;
  $("inputRow").hidden = true;
  $("btnStop").hidden = true;
  $("runPill").hidden = true;
  if (code === 0) consoleNote("Program finished.");
  else if (code) consoleNote("Program ended (code " + code + ").");
  setRunBusy(false);
}

$("btnRun").onclick = runProgram;
$("btnStop").onclick = async () => {
  if (session) {
    await post("/api/stop", { sid: session.sid });
    consoleNote("Stopped.");
    finishSession();
  }
};
$("stdinInput").addEventListener("keydown", async (e) => {
  if (e.key !== "Enter" || !session) return;
  const t = e.target.value;
  e.target.value = "";
  const d = document.createElement("div");
  d.className = "in"; d.textContent = "\u203A " + t;
  $("consoleOut").appendChild(d); autoscroll();
  await post("/api/input", { sid: session.sid, text: t });
});

/* -------------------------------------------------------------- files ---- */
async function refreshInfo() {
  try { info = await get("/api/info"); } catch (e) {}
  return info;
}

async function newFile() {
  if (!guardDirty()) return;
  showModal("New program", `
    <label class="field-label">Give it a name</label>
    <input type="text" id="npName" value="my-first-game" spellcheck="false">
    <div class="row-btns">
      <button class="bigbtn primary" id="npGo"><span>Create</span>
      <small>You can always rename it when saving</small></button>
    </div>`);
  $("npName").select();
  $("npGo").onclick = async () => {
    const r = await post("/api/new", { name: $("npName").value });
    if (!r.ok) { toast(r.error || "could not create", "err"); return; }
    closeModal();
    const content = maybeRestore(r.name,
      '# your program starts here\n\nprint "Hello, world!"\n');
    setFile({ name: r.name, content, origin: "new" });
    toast("New program: " + r.name, "ok");
  };
}

async function openModal() {
  await refreshInfo();
  const rows = (info.files || []).slice().sort((a, b) => b.mtime - a.mtime)
    .map((f) => `
      <button class="file-row" data-name="${esc(f.name)}">
        <span class="fname">${esc(f.name)}</span>
        <span class="fmeta">${fmtSize(f.size)} · ${fmtWhen(f.mtime)}</span>
      </button>`).join("");
  const empty = '<p class="empty-note">No saved programs yet. Create one with ' +
    "<b>New</b>, load an <b>Example</b>, or drop a .dep file anywhere in " +
    "this window.</p>";
  showModal("Open a program", `
    <div>${rows || empty}</div>
    <div class="row-btns">
      <button class="bigbtn" id="opUpload"><span>Bring a file from this computer...</span>
      <small>Any .dep or text file</small></button>
    </div>`);
  document.querySelectorAll(".file-row").forEach((b) => {
    b.onclick = () => { closeModal(); openFromWs(b.dataset.name); };
  });
  $("opUpload").onclick = () => $("filePick").click();
}

async function openFromWs(name) {
  if (!guardDirty()) return;
  const r = await post("/api/open", { name });
  if (!r.ok) { toast(r.error || "could not open", "err"); return; }
  const content = maybeRestore(r.name, r.content);
  setFile({ name: r.name, content, origin: "ws" });
}

/* open a .dep file from anywhere on this computer (double-click / launcher) */
async function openFromPath(path) {
  if (!guardDirty()) return;
  const r = await post("/api/open", { path });
  if (!r.ok) { toast(r.error || "could not open that file", "err"); return; }
  const content = maybeRestore(r.name, r.content);
  setFile({ name: r.name, content, origin: "path", path: r.path });
  toast("Opened " + r.name + " -- Save writes back to the same file", "ok");
}

/* the folder a path-opened file lives in -- its pictures/sounds get found */
function assetBase() {
  return file && file.origin === "path" && file.path
    ? file.path.replace(/[\\/][^\\/]*$/, "") : undefined;
}

async function loadExample(name) {
  if (!guardDirty()) return;
  const r = await post("/api/example", { name });
  if (!r.ok) { toast(r.error || "no such example", "err"); return; }
  const content = maybeRestore(r.name, r.content);
  setFile({ name: r.name, content, origin: "example" });
  toast("Loaded -- now press Run", "ok");
}

async function saveFile() {
  if (!file) { toast("Nothing to save yet", "err"); return; }
  if (file.origin === "path") {
    const r = await post("/api/save", { path: file.path, content: ed.value });
    if (r.ok) {
      file.name = r.name; file.content = ed.value;
      try { localStorage.removeItem("depdraft:" + r.name); } catch (e) {}
      $("fileName").textContent = r.name;
      updateDirty(); updateMode();
      toast("Saved " + r.name, "ok");
    } else toast(r.error || "save failed", "err");
    return;
  }
  if (file.origin !== "ws") {
    const exists = (info.files || []).some((f) => f.name === file.name);
    if (exists && !confirm(file.name +
        " already exists in your programs.\nReplace it with this version?")) return;
  }
  const r = await post("/api/save", { name: file.name, content: ed.value });
  if (r.ok) {
    file.name = r.name; file.content = ed.value; file.origin = "ws";
    try { localStorage.removeItem("depdraft:" + r.name); } catch (e) {}
    $("fileName").textContent = r.name;
    updateDirty(); updateMode();
    toast("Saved " + r.name, "ok");
    refreshInfo().then(buildRecent);
  } else toast(r.error || "save failed", "err");
}

function readFileIntoEditor(f) {
  if (!guardDirty()) return;
  const rd = new FileReader();
  rd.onload = () => {
    const name = f.name.replace(/\.(txt|dep)$/i, "") + ".dep";
    const content = maybeRestore(name, String(rd.result));
    setFile({ name, content, origin: "new" });
    toast("Loaded -- press Save to keep a copy here", "ok");
  };
  rd.readAsText(f);
}
$("filePick").addEventListener("change", (e) => {
  const f = e.target.files[0];
  if (f) readFileIntoEditor(f);
  e.target.value = "";
});
["dragover", "drop"].forEach((ev) =>
  document.addEventListener(ev, (e) => e.preventDefault()));
document.addEventListener("drop", (e) => {
  const f = e.dataTransfer && e.dataTransfer.files[0];
  if (f && /\.(dep|txt)$/i.test(f.name)) readFileIntoEditor(f);
});

$("btnNew").onclick = newFile;
$("btnOpen").onclick = openModal;
$("btnSave").onclick = saveFile;

/* -------------------------------------------------------------- build ---- */
function errHtml(r) {
  return '<p class="note-line" style="color:var(--red)">' + esc(r.error || "build failed") +
    (r.line ? ' &nbsp;<a href="#" class="errjump" data-line="' + r.line +
    '">go to line ' + r.line + "</a>" : "") + "</p>";
}

function openBuild() {
  if (!file) { toast("Create or open a program first", "err"); return; }
  const base = (file.name || "my-program").replace(/\.dep$/i, "");
  const natBtn = info.can_windows && !info.preview
    ? `<button class="bigbtn" id="bNat"><span>For this PC (${esc(info.native_label)})</span>
       <small>A file that runs right here</small></button>` : "";
  showModal("Build a program file", `
    <label class="field-label">Name for the built program</label>
    <input type="text" id="bName" value="${esc(base)}" spellcheck="false">
    <div class="row-btns">
      <button class="bigbtn primary" id="bWin"><span>Windows .exe</span>
      <small>A file anyone on Windows can double-click -- nothing else needed</small></button>
      ${natBtn}
    </div>
    <div class="build-status" id="bStatus"></div>`);
  const go = async (target) => {
    document.querySelectorAll(".row-btns .bigbtn").forEach((b) => b.disabled = true);
    $("bStatus").innerHTML = '<span class="spin">Compiling' +
      (target === "windows" ? " a real Windows executable" : "") +
      " -- the very first build can take a minute...</span>";
    try {
      const r = await post("/api/build", {
        out_name: $("bName").value || base, target,
        content: ed.value, name: file.name, asset_base: assetBase(),
      });
      if (!r.ok) { $("bStatus").innerHTML = errHtml(r); return; }
      let h = "";
      if (r.download_url) {
        h += `<div class="dl-line"><a class="dlbtn" href="${r.download_url}"
              download="${esc(r.filename)}">Download ${esc(r.filename)}
              <small>${fmtSize(r.size)}</small></a></div>`;
      } else {
        h += '<p class="note-line">Built:</p><p class="path-line">' + esc(r.path) + "</p>";
      }
      if (r.note) h += '<p class="note-line">' + esc(r.note) + "</p>";
      if (r.windows)
        h += '<p class="note-line">Works on any 64-bit Windows -- send it to a friend.</p>';
      if (!info.preview && r.folder)
        h += `<div class="row-btns"><button class="bigbtn" id="bFolder">
              <span>Open the builds folder</span><small>${esc(r.folder)}</small></button></div>`;
      $("bStatus").innerHTML = h;
      const bf = $("bFolder");
      if (bf) bf.onclick = () => post("/api/openfolder", { path: r.folder });
    } catch (e) {
      $("bStatus").innerHTML = errHtml({ error: String(e) });
    }
  };
  $("bWin").onclick = () => go("windows");
  const bn = $("bNat");
  if (bn) bn.onclick = () => go("native");
}
$("btnBuild").onclick = openBuild;

/* --------------------------------------------------------------- help ---- */
const CHEAT = `
<div class="cheat">
  <div><h4>Say things</h4>
<pre>print "Hello, world!"
print "score:", 10</pre></div>
  <div><h4>Remember things</h4>
<pre>set score to 0
change score by 10
set hero to {name: "Ada", x: 100}</pre></div>
  <div><h4>Questions and answers</h4>
<pre>set answer to ask "How old are you? "
if answer is nothing
  print "write a number please"
else
  print "in dog years that is", answer * 7
end</pre></div>
  <div><h4>Again and again</h4>
<pre>repeat 10 times
  print "ha"
end

for each item in items
  print item
end</pre></div>
  <div><h4>Your own words</h4>
<pre>function greet with name
  return "hi " + name
end

print greet("Ada")</pre></div>
  <div><h4>Make a game</h4>
<pre>use game kit

make game "Dot Chase" with width 400 and height 300

set dot to {x: 200, y: 150}

every frame
  if holding "left" then change dot.x by -4
  if holding "right" then change dot.x by 4
  clear "night blue"
  circle dot.x, dot.y, 8, "gold"
end

run game</pre></div>
</div>`;

function openHelp() {
  const links = (info.docs || []).map((d) =>
    '<a class="doc-link" href="/docs?page=' + esc(d.page) + '" target="_blank">' +
    esc(d.title) + "</a>").join("");
  const tourBtn = info.can_tour && !info.preview
    ? '<button class="doc-link" id="hTour">Take the tour in a terminal</button>' : "";
  showModal("Learn DeadEnd -- the 2-minute version", CHEAT + `
    <div class="doc-links">${links}
      ${tourBtn}
      <button class="doc-link" id="hDoctor">Check my computer is ready</button>
    </div>`);
  const ht = $("hTour");
  if (ht) ht.onclick = async () => {
    const r = await post("/api/tour", {});
    toast(r.ok ? "Tour opened in a new terminal window" :
                 "Could not open a terminal here", r.ok ? "ok" : "err");
  };
  $("hDoctor").onclick = async () => {
    showModal("Computer check", '<span class="spin">checking...</span>');
    const r = await post("/api/doctor", {});
    showModal("Computer check",
      '<pre class="doctor-out">' + esc(r.text || r.error || "?") + "</pre>");
  };
}
$("btnHelp").onclick = openHelp;

/* -------------------------------------------------------------- modal ---- */
function showModal(title, html) {
  $("modalTitle").textContent = title;
  $("modalBody").innerHTML = html;
  $("modalBack").hidden = false;
}
function closeModal() { $("modalBack").hidden = true; }
$("modalX").onclick = closeModal;
$("modalBack").addEventListener("click", (e) => {
  if (e.target === $("modalBack")) closeModal();
});
$("modalBody").addEventListener("click", (e) => {
  const a = e.target.closest(".errjump");
  if (a) { e.preventDefault(); closeModal(); gotoLine(+a.dataset.line); }
});

/* ------------------------------------------------------- welcome/menus --- */
function buildRecent() {
  const files = (info.files || []).slice().sort((a, b) => b.mtime - a.mtime).slice(0, 6);
  $("wRecent").hidden = !files.length;
  const list = $("wRecentList");
  list.innerHTML = "";
  files.forEach((f) => {
    const b = document.createElement("button");
    b.className = "w-recent-item";
    b.innerHTML = esc(f.name) + "<small>" + fmtSize(f.size) + "</small>";
    b.onclick = () => openFromWs(f.name);
    list.appendChild(b);
  });
}
function buildExMenu() {
  const m = $("exMenu");
  m.innerHTML = "";
  const note = document.createElement("div");
  note.className = "menu-note";
  note.textContent = "Loads into the editor -- Save keeps your own copy";
  m.appendChild(note);
  (info.examples || []).forEach((ex) => {
    const b = document.createElement("button");
    b.className = "menu-item";
    b.innerHTML = "<span>" + esc(ex.title) + "</span>" +
      (ex.desc ? "<small>" + esc(ex.desc) + "</small>" : "");
    b.onclick = () => { m.classList.remove("open"); loadExample(ex.name); };
    m.appendChild(b);
  });
}
$("btnExamples").onclick = (e) => {
  e.stopPropagation();
  $("exMenu").classList.toggle("open");
};
document.addEventListener("click", (e) => {
  if (!e.target.closest("#exDropdown")) $("exMenu").classList.remove("open");
});

$("wNew").onclick = newFile;
$("wFlappy").onclick = () => loadExample("flappy");
$("wExamples").onclick = (e) => {
  e.stopPropagation();
  $("exMenu").classList.add("open");
};
$("wLearn").onclick = openHelp;

/* ------------------------------------------------------ global shortcuts - */
document.addEventListener("keydown", (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") {
    e.preventDefault(); saveFile();
  }
  if (e.key === "F5" || ((e.ctrlKey || e.metaKey) && e.key === "Enter")) {
    e.preventDefault(); runProgram();
  }
  if (e.key === "Escape") {
    if (!$("modalBack").hidden) closeModal();
    $("exMenu").classList.remove("open");
  }
});
window.addEventListener("beforeunload", (e) => {
  if (file && ed.value !== file.content) { e.preventDefault(); e.returnValue = ""; }
});

/* --------------------------------------------------------------- init ---- */
(async function init() {
  await refreshInfo();
  if (info.version) {
    $("verChip").textContent = "v" + info.version;
    $("verChip").hidden = false;
  }
  if (info.preview) {
    $("previewChip").hidden = false;
    $("wPreviewNote").hidden = false;
  }
  buildExMenu();
  buildRecent();
  // opened via "dec studio game.dep" or a double-clicked .dep file
  const qp = new URLSearchParams(location.search);
  const qfile = qp.get("file");
  if (qfile) await openFromPath(qfile);
})();
