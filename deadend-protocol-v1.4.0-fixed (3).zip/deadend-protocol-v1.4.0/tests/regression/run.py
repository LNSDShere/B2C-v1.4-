#!/usr/bin/env python3
"""Regression tests for the v1.4.0 bug fixes.

Each case is a .dep file plus either:
  <name>.expected  -- exact stdout, program exits 0
  <name>.error     -- substring of stderr, program exits 1 (compile or run)

Run:  python3 tests/regression/run.py
"""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))          # repo root
DEC = os.path.join(ROOT, "src", "dec.py")


def main():
    cases = sorted(f[:-4] for f in os.listdir(HERE)
                   if f.endswith(".dep"))
    passed = failed = 0
    for name in cases:
        path = os.path.join(HERE, name + ".dep")
        exp_path = os.path.join(HERE, name + ".expected")
        err_path = os.path.join(HERE, name + ".error")
        r = subprocess.run([sys.executable, DEC, "run", path],
                           capture_output=True, text=True, timeout=120)
        if os.path.isfile(exp_path):
            expected = open(exp_path, encoding="utf-8").read()
            if r.returncode == 0 and r.stdout == expected:
                passed += 1
                print(f"  ok    {name}")
            else:
                failed += 1
                print(f"  FAIL  {name}")
                print(f"        exit {r.returncode}; stdout={r.stdout!r}")
                print(f"        stderr={r.stderr.strip()[:300]!r}")
        elif os.path.isfile(err_path):
            needle = open(err_path, encoding="utf-8").read().strip()
            if r.returncode == 1 and needle in r.stderr:
                passed += 1
                print(f"  ok    {name}")
            else:
                failed += 1
                print(f"  FAIL  {name}")
                print(f"        exit {r.returncode}; stderr={r.stderr.strip()[:300]!r}")
                print(f"        wanted exit 1 + {needle!r}")
        else:
            failed += 1
            print(f"  FAIL  {name} (no .expected or .error)")
    print(f"\n{passed} passed, {failed} failed, {len(cases)} total")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
