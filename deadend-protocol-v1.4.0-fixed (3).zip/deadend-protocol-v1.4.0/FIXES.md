# DeadEnd v1.4.0 — bug fixes

Every bug below was found by code review + an adversarial test battery, confirmed
against the unfixed code, fixed, and locked in by `tests/regression/` (11 cases),
the built-in suite (`dec test`, 11/11 including the kit tests under Xvfb), an
AddressSanitizer harness, a compile check of every example and every tour lesson,
and runtime runs of all 13 examples.

## Compiler front end (`src/dep_parse.py`)

1. **Bare built-ins rejected negative arguments.** The documented forms
   `abs -5`, `min -3, 9`, `random -1, 6` parsed as *subtraction*
   (`abs -5` → `abs() - 5`), so they failed with confusing errors.
   `_starts_neg_value` + `NEG_ARG_BUILTINS` now let a built-in math word take a
   negative first argument — while `x - 5` stays subtraction and
   `clock - 5` still means `clock() - 5`.

2. **`f()` as a statement parsed as `f(f())`.** `ping()` became a call to
   `ping` with one bogus argument (the result of a second, nested `ping()`
   call) — double-calling the function or dying with `unexpected ) in an
   expression`. `parse_callstmt` now reads a parenthesised argument list when
   the matching `)` ends the line.

3. **Statements carried no source line.** `set`, `change`, `print`, `if`,
   `while`, loops, `return`, `break`, `continue`, `exit` and friends had no
   line in the AST, which made correct runtime error reporting impossible
   (see bug 9). All statement tuples now carry their line.

## Compiler back end (`src/dep_emit.py`)

4. **UTF-8 text was mangled.** `c_str` kept only the low byte of every
   non-ASCII character (`日` → one wrong byte) and used `\xNN` escapes, which
   swallow following hex-looking characters. It now encodes the UTF-8 bytes
   exactly, with unambiguous 3-digit octal escapes.
   `"héllo wörld ✓ 日本語"` round-trips perfectly.

5. **Division by zero printed `inf` instead of erroring.** The typed
   fast path emitted raw C `a / b` (and `fmod(a, b)`), so `10 / 0` printed
   `inf` where the language reference promises
   `DeadEnd error (line 3): division by zero`. Both `/` and `%` now evaluate
   each side once and die with that exact message.

6. **Void results used as values broke the build.** `set r to say_hi()` where
   `say_hi` returns nothing produced a raw gcc error (`void value not
   ignored`) — or a Python `KeyError: 'void'` crash while declaring globals.
   Now: an English error (`'say_hi' doesn't give a value back ...`) at the
   right line, and `void` results can no longer poison type inference.

7. **Prelude contract mismatches.**
   - `dep_random1` (the 1-arg dice roll `random 6`) took a `DEPValue` while
     the emitter passes a plain `double` → *any* 1-arg `random` failed to
     compile with a gcc type error. Now `double`.
   - `dep_set_index2` released the index *after* `dep_set_index` had stored
     it as the map key — a textbook use-after-free for computed keys
     (`set m["k" + text i] to v` corrupts the heap; glibc aborts with
     `malloc(): unaligned tcache chunk detected`). The release is gone
     (ownership transfers; list indices are plain numbers).
   - `dep_save2` leaked the value it was handed (`save "f.txt", data`).

8. **Runtime errors all reported "line 1".** `__dep_line` existed in the
   runtime but generated code never wrote it. The emitter now emits
   `__dep_line = N;` before every statement (lines came from fix 3), so
   `dep_die` reports the true line — see `tests/regression/r01`.

## C runtime (`lib/dep_runtime.c`)

9. **Map hash-index double-insert.** After a grow-triggered `dep_map_rehash`
   (which already indexes the new entry), `dep_map_set` inserted the same
   entry into the open-addressing table *again* — a second slot pointing at
   one entry, breaking the table's invariants. The manual insert is skipped
   when a rehash just ran.

## Game kit (`lib/gamekit.c`)

10. **Music switched = music leaked.** `dep_g_music` loaded each new track
    over the old one without `UnloadMusicStream`, leaking the whole decoded
    stream (and its file handle) on every track change. The previous stream
    is now unloaded first (safe on a zeroed `Music` — verified in the vendored
    raylib: `UnloadAudioBuffer(NULL)` is a no-op).

11. **`dep_field_num` leaked every field read.** It dropped the owned value
    returned by `dep_field` — `hits` reads 8 fields per check, so a game
    checking collisions at 60 fps leaked continuously. Fixed with the missing
    `dep_release`.

12. **`dep_g_burst` leaked the particle-kind text** (`dep_cstr` borrows, the
    value was never released). Released after use.

## App kit (`lib/appkit.c`)

13. **`when button` on a non-button was a silent no-op.** Wiring
    `when button "out" is clicked` to a *label* silently registered nothing —
    the handler never ran and nothing explained why. `dep_app_on_click` now
    dies with `"out" is not a button, so 'when button "out" is clicked' would
    never run`.

## Motion kit (`lib/motionkit.c`)

14. **A tween never "finished" in small steps.** 120 ticks of 1/120 s sum to
    `0.9999999999999989`, so a 1-second tween was still `moving` after
    advancing a full second (and in a real 60 fps loop, a finished tween
    lingered for extra frames). The finish check now allows 1e-9 of slack.

15. **Pausing a timeline didn't pause steps already in flight.** `pause
    timeline` stopped the *schedule* but slots tick on independently, so the
    dot kept moving through the pause. Timelines now freeze the slots of
    running steps on pause and unfreeze them on resume / stop / play /
    `make timeline`.

## CLI (`src/dec.py`)

16. **`dec build file.dep -o`** (missing value) crashed with a Python
    traceback; `dec build -o out file.dep` treated `-o` as the program.
    Flag parsing now handles `-o` in any position and dies with a usage
    message; a missing output *directory* is created instead of crashing.

17. **`dec run --show-c file.dep`** treated `--show-c` as the file name
    (`cannot read --show-c`). Flags are now recognised in any position, and
    two program files is a clean usage error.

## Studio (`src/studio.py`)

18. **Windows cross-build failed to link every kit program.** The mingw
    command linked `gamekit.c` and `appkit.c` but not `motionkit.c`, so any
    game/app built through Studio's "Build for Windows" died with undefined
    references to `dep_m_*`. `motionkit.c` is on the link line now.

## Docs

19. **`docs/animation-kit.md` easing table contradicted the engine.**
    The engine maps `bouncy` → *bounce out* (`ease("bouncy", 0.5)` is
    0.765625), `snappy` → *back out*, `dramatic` → *expo in-out*; the table
    claimed back out / back in-out / bounce out. Corrected to match the code
    (the built-in `11-motion` test pins the numbers).

20. **`docs/language.md` showed a stray `end`** after the one-line `if`
    example, implying one-liners need `end` (they don't; typing it fails).

## Launchers / install (`dec`, `dec.bat`)

21. **`install.sh` installed a `dec` that could never run.** The launcher
    resolved the compiler as `$(dirname "$0")/src/dec.py`, but `install.sh`
    puts a *symlink* `~/.local/bin/dec -> <repo>/dec` on your PATH — and the
    dirname of the link is `~/.local/bin`, so every `dec` command died with
    `python3: can't open file '.../.local/bin/src/dec.py'` (verified by
    reproducing the exact install). Worse, any *other* copy of the launcher
    left on PATH from an older tree keeps shadowing the fixed one silently.
    The launcher now resolves the full symlink chain before locating
    `src/dec.py`.

22. **`dec.bat` changed the current directory.** It began with
    `cd /d "%~dp0"`, so a relative program path was resolved against the
    *launcher's* folder instead of yours (`dec run examples\pong.dep` from
    the repo root looked for `examples\examples\pong.dep`-style paths), and
    you could not tell *which* copy of DeadEnd was actually running when an
    older one was on PATH. dec.py locates all of its own files from its own
    location, so the `cd` was pure harm: removed. dec.bat now resolves every
    path from `%~dp0` and leaves your current directory alone.

23. **Stale `dec` copies were undetectable.** `dec version` now prints a
    build tag (`dec 1.4.0 -- DeadEnd compiler (build 2026-10-30)`, same in
    `dec doctor`), so if an older DeadEnd somewhere else on PATH answers,
    the missing/wrong tag exposes it immediately. See `UPGRADE.txt` for the
    two commands that fix a shadowed install.

## Kits on Windows (`src/dec.py`, new `tools/raylib`)

24. **The first kit program crashed with a Python traceback on Windows.**
    `build_raylib()` ran `sh vendor/raylib/build_raylib.sh` — there is no
    POSIX shell on Windows, so the very first `dec run <game>.dep` died with
    `FileNotFoundError: [WinError 2] The system cannot find the file
    specified` (reproduced from the user's traceback; and under Git-Bash it
    would have failed anyway, because the shell script cannot select the
    Win32 GLFW backend). raylib is now compiled **directly** with the C
    compiler and archived with `ar` (`_build_raylib_direct`): the exact same
    flags as the script (`-O2 -DPLATFORM_DESKTOP -DGRAPHICS_API_OPENGL_33`,
    `-D_GLFW_WIN32` on Windows / `-D_GLFW_X11` + `-fPIC` on Linux, with the
    ALSA-less retry for silent sound), nothing else needed. Verified two
    ways: a fresh-cache Linux build + kit game run, and a full MinGW-w64
    cross-build of raylib plus a link of a generated game-kit program to a
    PE32+ executable. Also: if no C compiler is installed, the failure is
    now a clean message with Windows install steps (was: traceback). And
    the package ships a **prebuilt win64 raylib** at
    `tools/raylib/libraylib.a` (which `raylib_dir()` already knew how to
    prefer), so on Windows the "building raylib" step usually never runs.

## Install (`install.bat`)

25. **`dec` only worked in the folder that contains `dec.bat`.** Opening a
    terminal anywhere else and typing `dec` produced `'dec' is not
    recognized as an internal or external command`. `install.bat` now adds
    step [4/4]: it writes a one-line `dec.cmd` shim into
    `%LOCALAPPDATA%\Microsoft\WindowsApps` (already on the per-user PATH)
    that forwards to the package's `dec.bat` — after installing once,
    `dec` works in every new terminal from every folder. Written with
    goto-flow (no parenthesised blocks) so package paths containing `(1)`
    cannot break batch parsing.

## Silent window death (`src/dec.py`, `lib/gamekit.c`, `lib/appkit.c`)

26. **Kit programs that failed to open a window died with zero output.**
    Reported live: `dec pong.dep` / `dec animated-todo.dep` returned to the
    prompt "like it opened and closed". The chain: the kits silence raylib's
    INFO log (`SetTraceLogLevel(LOG_WARNING)`), raylib's
    `WindowShouldClose()` returns `true` the moment the window is not
    ready, and `dec run` used `os.execv` — so a failed GLFW init or any
    startup crash produced an instant, *silent*, clean-looking exit. Three
    changes: `dec run` on Windows now runs the game as a child with the
    console attached and **decodes the exit code** (0xC0000135 missing DLL,
    0xC0000005 crash, plain 1 window-init failure — each with a hint, plus
    the built exe's path); `DEP_TRACE=1` now shows raylib's own init log
    (`Initializing raylib`, `GLFW: ...`, `DISPLAY: ...`) in both kits; and
    the failure is no longer invisible.

27. **Windows exes could depend on MinGW runtime DLLs.** Nothing forced
    `libgcc`/`libwinpthread` to link statically, so an exe built with a
    posix-threads MinGW could refuse to start on a machine without
    `libwinpthread-1.dll` — again silently, for a GUI-subsystem program.
    All Windows links now pass `-static`; the exe imports only system DLLs
    (verified: KERNEL32/USER32/GDI32/WINMM/SHELL32/msvcrt).

28. **`dec doctor` never tested the kit toolchain.** It compiled only a
    console hello-world, so "your gcc and the shipped/prebuilt raylib
    disagree" (ABI flavour mismatch) surfaced only as a silently closing
    game. Doctor now also *links* a kit program without running it and
    reports `kit link : PASS/FAIL`.

## Regression suite

`tests/regression/` holds one test per fixed behaviour
(`python3 tests/regression/run.py`) — line numbers, map key ownership,
negative args, `f()` statements, UTF-8, division by zero, void values,
`random n`, motion epsilon, pause freezing, and map churn.

## Notes

- `clock`/`ALSA` warnings in the sandbox are environmental (no sound card),
  not bugs.
- raylib/X11 builds in this repo can be exercised headless with Xvfb:
  `Xvfb :99 &` then `DISPLAY=:99 DEP_FRAMES=3 dec run tests/09-game.dep`.
