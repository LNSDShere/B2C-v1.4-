# DeadEnd Studio

Studio is DeadEnd's editor for people who do not want a terminal. You write
English on the left, press buttons on top, and real programs come out. It runs
in your browser but lives on your own computer -- nothing goes anywhere.

**On Windows with the installer:** just double-click the **DeadEnd Studio**
shortcut on your desktop. You never see a terminal at all.

Start it from a terminal (any OS) with:

```
dec studio
```

Your browser opens with the editor in it. Keep the small console window that
appeared open while you work; closing it stops Studio.

## Opening any .dep file

Double-click a `.dep` file anywhere on your computer (Desktop, Downloads,
wherever) and it opens in DeadEnd Studio -- the same way `.txt` files open in
Notepad. The first double-click starts Studio; while Studio is running, every
next file opens instantly in it.

**Save** writes the file back to where it came from. If the program uses
pictures or sounds that live next to the file, they are found automatically
when you press **Run** or **Build .exe**.

You can also start Studio with a file from a terminal: `dec studio game.dep`.

## The buttons

| Button | What it does |
|--------|--------------|
| **New** | A blank program with a name you pick |
| **Open** | Your saved programs, or any `.dep` file from your computer |
| **Save** | Keeps the program in your DeadEnd Programs folder |
| **Examples** | Ready-made programs (games included) to load, run, and poke at |
| **Run** | Compiles and runs what you wrote, right now |
| **Stop** | Ends a running program |
| **Build .exe** | Turns your program into a real Windows executable file |
| **Help** | The 2-minute language cheat sheet, the full docs, and the tour |

## Your first minute

1. Press **Examples** and load **flappy**.
2. Press **Run**. The game plays -- in the online preview you get live
   pictures of it running; on your PC a real window opens.
3. Change a number (gravity, pipe speed -- the comments tell you which).
   Press **Run** again. That is the whole loop: edit, run, edit, run.
4. Press **Build .exe** to get `flappy.exe` -- a file that runs on any
   64-bit Windows, no DeadEnd installed, nothing else needed.

## Where things live

* Your programs: `DeadEnd Programs` in your Documents folder.
* Built exes: `DeadEnd Programs/builds`.
* Unsaved work is auto-backed-up in your browser, and Studio offers to
  bring it back if you close the tab by accident.

## Programs that talk back

If a program uses `ask`, a typing box appears under the output -- type your
answer and press Enter. (Try the **guess** example.)

## Games need their pictures and sounds

If your program loads a picture or sound, **Build .exe** packs everything
into one zip. Unzip it into a folder and double-click the exe -- keep the
exe and the media in the same folder, like any other game.

## Keyboard shortcuts (optional -- every one of them is also a button)

* `Ctrl+Enter` or `F5` -- run
* `Ctrl+S` -- save
* `Tab` -- indent; Enter -- smart new line

## Troubleshooting

* **"No Windows compiler here"** when building an exe on Linux: install
  mingw-w64 (`sudo apt install gcc-mingw-w64-x86-64`), or build "For this
  PC" instead. On Windows and in the online preview this never happens.
* Press **Help -- Check my computer is ready** to run the doctor.
* A red line in the output panel jumps you to the offending line when
  clicked. Errors are written in English on purpose.
