/* ==========================================================================
 * DeadEnd App Dev Kit -- appkit.c  (built on raylib 5.5)
 * ========================================================================== */
#include "appkit.h"
#include "gamekit.h"
#include "motionkit.h"
#include "raylib.h"
#include <stdlib.h>
#include <string.h>

static const char *dep_cstr_of(DEPValue v, const char *what) {
    if (v.tag != DEP_T_TEXT)
        dep_die("%s needs the widget's name in text, got %s", what, dep_typename(v));
    return v.as.s->chars;
}

#define DEP_MAX_WIDGETS 256
#define DEP_FIELD_MAX 1024

typedef struct {
    int type;
    char name[128];
    double x, y, w, h;
    char *text;            /* field content / label text (heap) */
    long text_len, text_cap;
    int checked;           /* checkbox */
    double value;          /* slider 0..100 */
    Texture2D tex;
    int has_tex;
} DEPWidget;

static DEPWidget dep_widgets[DEP_MAX_WIDGETS];
static int dep_widget_count = 0;
static int dep_app_focus = -1;      /* focused field index */
static void (*dep_app_cbs[DEP_MAX_WIDGETS])(void);
static int dep_app_cursor_blink = 0;

static char dep_app_title[256] = "DeadEnd App";
static int dep_app_w = 480, dep_app_h = 320;

static void dep_ui_run(int op, const char *name, double dur, const char *feel,
                       int dir, double x, double y, double strength);

void dep_app_setup(DEPValue title, double w, double h) {
    if (title.tag == DEP_T_TEXT) {
        long n = title.as.s->len;
        if (n > 255) n = 255;
        memcpy(dep_app_title, title.as.s->chars, (size_t)n);
        dep_app_title[n] = '\0';
    }
    if (w > 0) dep_app_w = (int)w;
    if (h > 0) dep_app_h = (int)h;
    dep_m_set_ui_exec(dep_ui_run);   /* timelines can animate widgets too */
    dep_release(title);
}

static DEPWidget *dep_widget_by_name(const char *name) {
    for (int i = 0; i < dep_widget_count; i++)
        if (strcmp(dep_widgets[i].name, name) == 0) return &dep_widgets[i];
    return NULL;
}

void dep_app_add(int type, const char *name, double x, double y, double w, double h) {
    if (dep_widget_count >= DEP_MAX_WIDGETS) {
        dep_die("this app has too many widgets (limit %d)", DEP_MAX_WIDGETS);
    }
    if (dep_widget_by_name(name)) {
        dep_die("there is already a widget called \"%s\" -- widget names must "
                "be unique", name);
    }
    DEPWidget *g = &dep_widgets[dep_widget_count];
    memset(g, 0, sizeof(DEPWidget));
    g->type = type;
    long n = (long)strlen(name);
    if (n > 127) n = 127;
    memcpy(g->name, name, (size_t)n);
    g->name[n] = '\0';
    g->x = x; g->y = y;
    /* sensible defaults */
    double dw = w, dh = h;
    if (dw < 0) {
        switch (type) {
            case DEP_W_TITLE:  dw = 400; break;
            case DEP_W_LABEL:  dw = MeasureText(name, 20) + 8; break;
            case DEP_W_BUTTON: dw = MeasureText(name, 20) + 32; break;
            case DEP_W_FIELD:  dw = 200; break;
            case DEP_W_CHECKBOX: dw = 20; break;
            case DEP_W_SLIDER: dw = 160; break;
            case DEP_W_IMAGE:  dw = 100; break;
            case DEP_W_PANEL:  dw = 200; break;
            default: dw = 100;
        }
    }
    if (dh < 0) {
        switch (type) {
            case DEP_W_TITLE:  dh = 34; break;
            case DEP_W_LABEL:  dh = 24; break;
            case DEP_W_BUTTON: dh = 34; break;
            case DEP_W_FIELD:  dh = 28; break;
            case DEP_W_CHECKBOX: dh = 20; break;
            case DEP_W_SLIDER: dh = 20; break;
            case DEP_W_IMAGE:  dh = 100; break;
            case DEP_W_PANEL:  dh = 120; break;
            default: dh = 24;
        }
    }
    g->w = dw; g->h = dh;
    g->text_cap = 64;
    g->text = (char *)malloc(64);
    g->text[0] = '\0';
    g->text_len = 0;
    if (type == DEP_W_IMAGE) {
        g->tex = LoadTexture(name);
        g->has_tex = 1;
        if (w < 0) g->w = g->tex.width;
        if (h < 0) g->h = g->tex.height;
    }
    dep_widget_count++;
}

void dep_app_on_click(const char *name, void (*fn)(void)) {
    for (int i = 0; i < dep_widget_count; i++) {
        if (strcmp(dep_widgets[i].name, name) == 0 && dep_widgets[i].type == DEP_W_BUTTON) {
            dep_app_cbs[i] = fn;
            return;
        }
    }
    DEPWidget *g = dep_widget_by_name(name);
    if (!g) {
        dep_die("there is no button called \"%s\" (add it first with "
                "'add button \"%s\" ...')", name, name);
    }
    if (g->type != DEP_W_BUTTON) {
        dep_die("\"%s\" is not a button, so 'when button \"%s\" is clicked' "
                "would never run", name, name);
    }
}

/* ---------------- reading / writing widget values ---------------- */
static DEPWidget *dep_widget_or_die(const char *name, int type, const char *what) {
    DEPWidget *g = dep_widget_by_name(name);
    if (!g) dep_die("there is no %s called \"%s\"", what, name);
    if (g->type != type) dep_die("\"%s\" is not a %s", name, what);
    return g;
}

DEPStr *dep_a_field(DEPValue name) {
    DEPWidget *g = dep_widget_or_die(dep_cstr_of(name, "field"), DEP_W_FIELD, "field");
    DEPStr *r = dep_str_new(g->text, g->text_len);
    dep_release(name);
    return r;
}

DEPStr *dep_a_label(DEPValue name) {
    DEPWidget *g = dep_widget_or_die(dep_cstr_of(name, "label"), DEP_W_LABEL, "label");
    const char *t = g->text[0] ? g->text : g->name;
    DEPStr *r = dep_str_new(t, (long)strlen(t));
    dep_release(name);
    return r;
}

int dep_a_checkbox(DEPValue name) {
    DEPWidget *g = dep_widget_or_die(dep_cstr_of(name, "checkbox"), DEP_W_CHECKBOX, "checkbox");
    dep_release(name);
    return g->checked;
}

double dep_a_slider(DEPValue name) {
    DEPWidget *g = dep_widget_or_die(dep_cstr_of(name, "slider"), DEP_W_SLIDER, "slider");
    dep_release(name);
    return g->value;
}

void dep_app_set_text(const char *name, DEPValue text) {
    DEPWidget *g = dep_widget_by_name(name);
    if (!g) { dep_release(text); return; }
    if (g->type == DEP_W_FIELD) {
        const char *s = (text.tag == DEP_T_TEXT) ? text.as.s->chars : "";
        long n = (text.tag == DEP_T_TEXT) ? text.as.s->len : 0;
        if (n > DEP_FIELD_MAX - 1) n = DEP_FIELD_MAX - 1;
        if ((long)g->text_cap < n + 1) {
            while ((long)g->text_cap < n + 1) g->text_cap *= 2;
            g->text = (char *)realloc(g->text, (size_t)g->text_cap);
        }
        memcpy(g->text, s, (size_t)n);
        g->text[n] = '\0';
        g->text_len = n;
    } else if (g->type == DEP_W_LABEL || g->type == DEP_W_BUTTON) {
        const char *s = (text.tag == DEP_T_TEXT) ? text.as.s->chars : "";
        long n = (text.tag == DEP_T_TEXT) ? text.as.s->len : 0;
        free(g->text);
        g->text_cap = n + 8;
        g->text = (char *)malloc((size_t)g->text_cap);
        memcpy(g->text, s, (size_t)n);
        g->text[n] = '\0';
        g->text_len = n;
    }
    dep_release(text);
}

void dep_app_set_val(const char *name, DEPValue val) {
    DEPWidget *g = dep_widget_by_name(name);
    if (!g) { dep_release(val); return; }
    if (g->type == DEP_W_CHECKBOX) {
        g->checked = dep_truthy(val);
    } else if (g->type == DEP_W_SLIDER) {
        g->value = (val.tag == DEP_T_NUM) ? val.as.n : 0;
        if (g->value < 0) g->value = 0;
        if (g->value > 100) g->value = 100;
    }
    dep_release(val);
}

/* ---------------- interaction + run ---------------- */
static int dep_hit_rect(double x, double y, double w, double h, double mx, double my) {
    return mx >= x && mx <= x + w && my >= y && my <= y + h;
}

static Color dep_ui_col(Color base, double alpha) {
    int a = (int)(base.a * alpha);
    if (a < 0) a = 0;
    if (a > 255) a = 255;
    base.a = (unsigned char)a;
    return base;
}

/* ---------------- UI motion (v1.4.0) ----------------
 * The generated code (and the timeline engine) call these; they resolve the
 * widget, turn direction words into ids, and drive the motion engine. */

static int dep_ui_dir_of(const char *s) {
    if (strcmp(s, "left") == 0) return 0;
    if (strcmp(s, "right") == 0) return 1;
    if (strcmp(s, "top") == 0 || strcmp(s, "up") == 0) return 2;
    if (strcmp(s, "bottom") == 0 || strcmp(s, "down") == 0) return 3;
    dep_die("slide direction must be \"left\", \"right\", \"top\" or "
            "\"bottom\" (got \"%s\")", s);
    return 0;
}

static double dep_ui_slide_dist(DEPWidget *g, int dir) {
    switch (dir) {
    case 0: return g->x + g->w + 24;        /* from off the left edge */
    case 1: return dep_app_w - g->x + 24;   /* off the right edge */
    case 2: return g->y + g->h + 24;        /* off the top */
    default: return dep_app_h - g->y + 24;  /* off the bottom */
    }
}

/* engine hook (timeline ui steps land here too) */
static void dep_ui_run(int op, const char *name, double dur, const char *feel,
                       int dir, double x, double y, double strength) {
    if (op == DEP_UI_SLIDE_IN || op == DEP_UI_SLIDE_OUT) {
        DEPWidget *g = dep_widget_by_name(name);
        if (g) x = dep_ui_slide_dist(g, dir);
    }
    dep_m_ui_exec(op, name, dur, feel, dir, x, y, strength);
}

static DEPWidget *dep_ui_widget(const char *name, const char *what) {
    DEPWidget *g = dep_widget_by_name(name);
    if (!g)
        dep_die("there is no widget called \"%s\" to %s (add it first)",
                name, what);
    return g;
}

void dep_ui_pop_in(const char *name, double dur, DEPValue feel) {
    dep_ui_widget(name, "pop in");
    dep_ui_run(DEP_UI_POP_IN, name, dur,
               (feel.tag == DEP_T_TEXT) ? feel.as.s->chars : NULL, 0, 0, 0, 0);
    dep_release(feel);
}

void dep_ui_pop_out(const char *name, double dur, DEPValue feel) {
    dep_ui_widget(name, "pop out");
    dep_ui_run(DEP_UI_POP_OUT, name, dur,
               (feel.tag == DEP_T_TEXT) ? feel.as.s->chars : NULL, 0, 0, 0, 0);
    dep_release(feel);
}

void dep_ui_fade_in(const char *name, double dur, DEPValue feel) {
    dep_ui_widget(name, "fade in");
    dep_ui_run(DEP_UI_FADE_IN, name, dur,
               (feel.tag == DEP_T_TEXT) ? feel.as.s->chars : NULL, 0, 0, 0, 0);
    dep_release(feel);
}

void dep_ui_fade_out(const char *name, double dur, DEPValue feel) {
    dep_ui_widget(name, "fade out");
    dep_ui_run(DEP_UI_FADE_OUT, name, dur,
               (feel.tag == DEP_T_TEXT) ? feel.as.s->chars : NULL, 0, 0, 0, 0);
    dep_release(feel);
}

void dep_ui_slide_in(const char *name, DEPValue dir, double dur, DEPValue feel) {
    DEPWidget *g = dep_ui_widget(name, "slide in");
    (void)g;
    int d = dep_ui_dir_of((dir.tag == DEP_T_TEXT) ? dir.as.s->chars : "left");
    dep_release(dir);
    dep_ui_run(DEP_UI_SLIDE_IN, name, dur,
               (feel.tag == DEP_T_TEXT) ? feel.as.s->chars : NULL, d, 0, 0, 0);
    dep_release(feel);
}

void dep_ui_slide_out(const char *name, DEPValue dir, double dur, DEPValue feel) {
    DEPWidget *g = dep_ui_widget(name, "slide out");
    (void)g;
    int d = dep_ui_dir_of((dir.tag == DEP_T_TEXT) ? dir.as.s->chars : "right");
    dep_release(dir);
    dep_ui_run(DEP_UI_SLIDE_OUT, name, dur,
               (feel.tag == DEP_T_TEXT) ? feel.as.s->chars : NULL, d, 0, 0, 0);
    dep_release(feel);
}

void dep_ui_glide(const char *name, double x, double y, double dur, DEPValue feel) {
    DEPWidget *g = dep_ui_widget(name, "glide");
    dep_ui_run(DEP_UI_GLIDE, name, dur,
               (feel.tag == DEP_T_TEXT) ? feel.as.s->chars : NULL, 0,
               x - g->x, y - g->y, 0);   /* offsets from the widget's base */
    dep_release(feel);
}

void dep_ui_shake(const char *name, double strength) {
    dep_ui_widget(name, "shake");
    dep_ui_run(DEP_UI_SHAKE, name, 0, NULL, 0, 0, 0, strength);
}

void dep_ui_bump(const char *name) {
    dep_ui_widget(name, "bump");
    dep_ui_run(DEP_UI_BUMP, name, 0, NULL, 0, 0, 0, 0);
}

static void dep_field_type(DEPWidget *g) {
    int c = GetCharPressed();
    while (c > 0) {
        if (c >= 32 && c < 127 && g->text_len < DEP_FIELD_MAX - 1) {
            if ((long)g->text_cap < g->text_len + 2) {
                g->text_cap *= 2;
                g->text = (char *)realloc(g->text, (size_t)g->text_cap);
            }
            g->text[g->text_len++] = (char)c;
            g->text[g->text_len] = '\0';
        }
        c = GetCharPressed();
    }
    if (IsKeyPressed(KEY_BACKSPACE) && g->text_len > 0) {
        g->text[--g->text_len] = '\0';
    }
}

void dep_app_run(void) {
    if (getenv("DEP_TRACE")) SetTraceLogLevel(LOG_INFO);
    else SetTraceLogLevel(LOG_WARNING);   /* DEP_TRACE=1 shows raylib init details */
    InitWindow(dep_app_w, dep_app_h, dep_app_title);
    SetTargetFPS(60);
    dep_window_open = 1;
    long limit = -1;
    const char *fl = getenv("DEP_FRAMES");
    if (fl) limit = atol(fl);
    long n = 0;
    while (!WindowShouldClose()) {
        double mx = GetMouseX(), my = GetMouseY();
        int clicked = IsMouseButtonPressed(MOUSE_BUTTON_LEFT);
        int down = IsMouseButtonDown(MOUSE_BUTTON_LEFT);
        dep_motion_tick(GetFrameTime());   /* move every animation one frame */
        BeginDrawing();
        ClearBackground((Color) { 242, 244, 248, 255 });
        dep_app_cursor_blink = (dep_app_cursor_blink + 1) % 60;
        for (int i = 0; i < dep_widget_count; i++) {
            DEPWidget *g = &dep_widgets[i];
            /* ---- motion kit state: offset, alpha, scale, hidden ---- */
            double adx, ady, aalpha, ascale;
            int ahidden;
            dep_m_ui_state(g->name, &adx, &ady, &aalpha, &ascale, &ahidden);
            if (ahidden || aalpha < 0.01) continue;
            if (ascale < 0.02) ascale = 0.02;
            double ex = g->x + adx + (g->w - g->w * ascale) / 2.0;
            double ey = g->y + ady + (g->h - g->h * ascale) / 2.0;
            double ew = g->w * ascale, eh = g->h * ascale;
            int hover = dep_hit_rect(ex, ey, ew, eh, mx, my);
            switch (g->type) {
                case DEP_W_PANEL:
                    DrawRectangle((int)ex, (int)ey, (int)ew, (int)eh,
                                  dep_ui_col((Color) { 226, 230, 238, 255 }, aalpha));
                    DrawRectangleLines((int)ex, (int)ey, (int)ew, (int)eh,
                                       dep_ui_col((Color) { 205, 210, 220, 255 }, aalpha));
                    break;
                case DEP_W_TITLE:
                    DrawTextEx(GetFontDefault(), g->text[0] ? g->text : g->name,
                               (Vector2) { (float)ex, (float)ey },
                               (float)(28 * ascale), 1.0f,
                               dep_ui_col((Color) { 25, 30, 45, 255 }, aalpha));
                    break;
                case DEP_W_LABEL:
                    DrawTextEx(GetFontDefault(), g->text[0] ? g->text : g->name,
                               (Vector2) { (float)ex, (float)ey },
                               (float)(20 * ascale), 1.0f,
                               dep_ui_col((Color) { 45, 50, 65, 255 }, aalpha));
                    break;
                case DEP_W_BUTTON: {
                    Color base = hover ? (Color) { 41, 128, 185, 255 }
                                       : (Color) { 52, 152, 219, 255 };
                    if (hover && down) base = (Color) { 31, 97, 141, 255 };
                    DrawRectangle((int)ex, (int)ey, (int)ew, (int)eh,
                                  dep_ui_col(base, aalpha));
                    DrawRectangleLines((int)ex + 1, (int)ey + 1, (int)ew - 2,
                                       (int)eh - 2,
                                       dep_ui_col((Color) { 30, 90, 130, 255 }, aalpha));
                    const char *t = g->text[0] ? g->text : g->name;
                    int tw = (int)(MeasureText(t, 20) * ascale);
                    DrawTextEx(GetFontDefault(), t,
                               (Vector2) { (float)(ex + (ew - tw) / 2.0),
                                           (float)(ey + (eh - 20 * ascale) / 2.0) },
                               (float)(20 * ascale), 1.0f,
                               dep_ui_col(WHITE, aalpha));
                    break;
                }
                case DEP_W_FIELD: {
                    Color bg = (dep_app_focus == i) ? WHITE : (Color) { 250, 250, 252, 255 };
                    DrawRectangle((int)ex, (int)ey, (int)ew, (int)eh,
                                  dep_ui_col(bg, aalpha));
                    DrawRectangleLines((int)ex, (int)ey, (int)ew, (int)eh,
                                       dep_ui_col((dep_app_focus == i)
                                                      ? (Color) { 52, 152, 219, 255 }
                                                      : (Color) { 190, 196, 206, 255 },
                                                  aalpha));
                    DrawTextEx(GetFontDefault(), g->text,
                               (Vector2) { (float)(ex + 8), (float)(ey + 5) },
                               (float)(20 * ascale), 1.0f,
                               dep_ui_col((Color) { 35, 40, 55, 255 }, aalpha));
                    if (dep_app_focus == i && dep_app_cursor_blink < 30) {
                        int cx = (int)(ex + 8 + MeasureText(g->text, 20) * ascale);
                        DrawTextEx(GetFontDefault(), "|",
                                   (Vector2) { (float)cx, (float)(ey + 5) },
                                   (float)(20 * ascale), 1.0f,
                                   dep_ui_col((Color) { 52, 152, 219, 255 }, aalpha));
                    }
                    break;
                }
                case DEP_W_CHECKBOX: {
                    DrawRectangle((int)ex, (int)ey, (int)ew, (int)eh,
                                  dep_ui_col(WHITE, aalpha));
                    DrawRectangleLines((int)ex, (int)ey, (int)ew, (int)eh,
                                       dep_ui_col((Color) { 120, 126, 140, 255 }, aalpha));
                    if (g->checked)
                        DrawTextEx(GetFontDefault(), "X",
                                   (Vector2) { (float)(ex + 4), (float)(ey + 1) },
                                   (float)(16 * ascale), 1.0f,
                                   dep_ui_col((Color) { 39, 174, 96, 255 }, aalpha));
                    DrawTextEx(GetFontDefault(), g->name,
                               (Vector2) { (float)(ex + ew + 8), (float)(ey + 1) },
                               16, 1.0f,
                               dep_ui_col((Color) { 45, 50, 65, 255 }, aalpha));
                    break;
                }
                case DEP_W_SLIDER: {
                    int ty = (int)(ey + eh / 2 - 2);
                    DrawRectangle((int)ex, ty, (int)ew, 4,
                                  dep_ui_col((Color) { 200, 205, 215, 255 }, aalpha));
                    int kx = (int)(ex + (ew - 12) * (g->value / 100.0));
                    DrawRectangle(kx, (int)ey, 12, (int)eh,
                                  dep_ui_col(hover ? (Color) { 41, 128, 185, 255 }
                                                   : (Color) { 90, 100, 120, 255 },
                                             aalpha));
                    DrawTextEx(GetFontDefault(), g->name,
                               (Vector2) { (float)ex, (float)(ey + eh + 4) },
                               14, 1.0f,
                               dep_ui_col((Color) { 90, 96, 110, 255 }, aalpha));
                    break;
                }
                case DEP_W_IMAGE:
                    if (g->has_tex)
                        DrawTextureEx(g->tex, (Vector2) { (float)ex, (float)ey },
                                      0.0f, (float)ascale,
                                      dep_ui_col(WHITE, aalpha));
                    break;
            }
            /* interaction (on the animated rectangle) */
            if (clicked && hover) {
                switch (g->type) {
                    case DEP_W_BUTTON:
                        if (dep_app_cbs[i]) dep_app_cbs[i]();
                        break;
                    case DEP_W_FIELD:
                        dep_app_focus = i;
                        break;
                    case DEP_W_CHECKBOX:
                        g->checked = !g->checked;
                        break;
                    default:
                        break;
                }
            }
            if (g->type == DEP_W_FIELD && dep_app_focus == i)
                dep_field_type(g);
            if (g->type == DEP_W_SLIDER && down && hover) {
                double rel = (mx - ex) / (ew > 0 ? ew : 1);
                if (rel < 0) rel = 0;
                if (rel > 1) rel = 1;
                g->value = rel * 100;
            }
        }
        EndDrawing();
        if (limit > 0 && ++n >= limit) break;
    }
    CloseWindow();
    dep_window_open = 0;
}
